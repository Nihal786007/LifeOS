// ==========================================
// LifeOS Execution Service
// ==========================================

import type {
  LifeGoal,
  MonthlyTarget,
  WeeklyTarget,
  Task,
} from "../shared/types";

export interface ExecutionState {
  lifeGoals: LifeGoal[];

  monthlyTargets: MonthlyTarget[];

  weeklyTargets: WeeklyTarget[];

  tasks: Task[];
}

export interface ExecutionResult {
  lifeGoals: LifeGoal[];

  monthlyTargets: MonthlyTarget[];

  weeklyTargets: WeeklyTarget[];

  tasks: Task[];
}

export class ExecutionService {
  static completeLifeGoal(
    state: ExecutionState,
    goalId: number
  ): ExecutionResult {
    const completedAt =
      new Date().toISOString();

    const monthlyTargetIds =
      state.monthlyTargets
        .filter(
          (target) =>
            target.goalId === goalId
        )
        .map((target) => target.id);

    const weeklyTargetIds =
      state.weeklyTargets
        .filter((target) =>
          monthlyTargetIds.includes(
            target.monthlyTargetId ?? -1
          )
        )
        .map((target) => target.id);

    return {
      lifeGoals: state.lifeGoals.map(
        (goal) =>
          goal.id === goalId
            ? {
                ...goal,
                progress: 100,
                completed: true,
                completedAt,
              }
            : goal
      ),

      monthlyTargets:
        state.monthlyTargets.map(
          (target) =>
            monthlyTargetIds.includes(
              target.id
            )
              ? {
                  ...target,
                  progress: 100,
                  completed: true,
                  completedAt,
                }
              : target
        ),

      weeklyTargets:
        state.weeklyTargets.map(
          (target) =>
            weeklyTargetIds.includes(
              target.id
            )
              ? {
                  ...target,
                  progress: 100,
                  completed: true,
                  completedAt,
                }
              : target
        ),

      tasks: state.tasks.map(
        (task) =>
          weeklyTargetIds.includes(
            task.weeklyTargetId ?? -1
          )
            ? {
                ...task,
                completed: true,
                completedAt,
              }
            : task
      ),
    };
  }

  static uncompleteLifeGoal(
    state: ExecutionState,
    goalId: number
  ): ExecutionResult {
    return {
      ...state,
    };
  }

  static deleteLifeGoal(
    state: ExecutionState,
    goalId: number
  ): ExecutionResult {
    return {
      ...state,
    };
  }

  static completeMonthlyTarget(
    state: ExecutionState,
    monthlyTargetId: number
  ): ExecutionResult {
    return {
      ...state,
    };
  }

  static uncompleteMonthlyTarget(
    state: ExecutionState,
    monthlyTargetId: number
  ): ExecutionResult {
    return {
      ...state,
    };
  }

  static deleteMonthlyTarget(
    state: ExecutionState,
    monthlyTargetId: number
  ): ExecutionResult {
    return {
      ...state,
    };
  }

  static completeWeeklyTarget(
    state: ExecutionState,
    weeklyTargetId: number
  ): ExecutionResult {
    return {
      ...state,
    };
  }

  static uncompleteWeeklyTarget(
    state: ExecutionState,
    weeklyTargetId: number
  ): ExecutionResult {
    return {
      ...state,
    };
  }

  static deleteWeeklyTarget(
    state: ExecutionState,
    weeklyTargetId: number
  ): ExecutionResult {
    return {
      ...state,
    };
  }

  static completeTask(
    state: ExecutionState,
    taskId: number
  ): ExecutionResult {
    return {
      ...state,
    };
  }

  static uncompleteTask(
    state: ExecutionState,
    taskId: number
  ): ExecutionResult {
    return {
      ...state,
    };
  }

  static deleteTask(
    state: ExecutionState,
    taskId: number
  ): ExecutionResult {
    return {
      ...state,
    };
  }
}